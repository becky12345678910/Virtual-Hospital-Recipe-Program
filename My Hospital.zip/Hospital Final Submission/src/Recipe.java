/**
 * The Recipe class handles the information a single recipe.
 * Sources:
 * Recipes for diabetics:
 * http://www.eatingwell.com/recipes/22609/health-condition/diabetic/breakfast/
 * https://www.diabetes.ca/diabetes-and-you/recipes.aspx
 * Recipes for cancer patients:
 * http://www.cancer.ca/en/support-and-services/resources/recipes/during-treatment/?region=on
 * http://www.eatingwell.com/recipes/17916/mealtimes/breakfast-brunch/
 * https://www.cancer.org/healthy/eat-healthy-get-active/eat-healthy/find-healthy-recipes/main-dishes.html
 *
 * @author Rebecca Xie
 * @version 1.0
 * @since 2018-04
 */

public class Recipe {
    public String title = "", ingredients = "", instructions = "", condition = "", nutritional_info = "", allergy = "", dietRestriction = "";

    public Recipe(String title, String ingredients, String instructions, String condition, String nutritional_info, String allergy,
                  String dietRestriction){
        this.title = title;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.condition = condition;
        this.nutritional_info = nutritional_info;
        this.allergy = allergy;
        this.dietRestriction = dietRestriction;

    }

    public Recipe(){

    }

    @Override
    public String toString(){
        return title;
    }
}
