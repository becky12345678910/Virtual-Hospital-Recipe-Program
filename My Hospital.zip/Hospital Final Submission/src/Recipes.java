import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * The Recipes class represents multiple recipes. It parses the recipes.txt file.
 * Sources: https://stackoverflow.com/questions/787735/what-is-parse-parsing
 *
 * @author Rebecca Xie
 * @version 1.0
 * @since 2018-04
 */
public class Recipes {
    public ArrayList<Recipe> recipes = new ArrayList<>();
    public String FILE_NAME = "recipes.txt";

    /*
    Keeps track of the sections of the recipe file
     */
    enum ParseState{
        Title,
        Recipe,
        Ingredients,
        Instructions,
        Nutrition,
        Diet,
        Extra
    }

    /**
     * Function: read
     * Description: Reads the text file separates it into sections, named after the enum
     * variables.
     */

    public void read(){
        Scanner input = null;
        // setup
        try {
            input = new Scanner(new File(FILE_NAME));
            Recipe current_recipe = null;
            ParseState state = ParseState.Recipe;   // Parsing is reading text file and putting it into objects
            // reading input
            while (input.hasNextLine()) {
                String line = input.nextLine();
                // looking for the parts of the recipe i.e. seperating parts of the recipe
                if (line.startsWith("Recipe")){
                    if (current_recipe != null){
                        recipes.add(current_recipe);    // done with current recipe, adding new recipe to list
                    }
                    current_recipe = new Recipe();  // starting new recipe
                    current_recipe.condition = line.split(": ")[1];
                    state = ParseState.Recipe;
                } else if (line.startsWith("Title")) {
                    current_recipe.title = line.split(": ")[1];
                    state = ParseState.Title;
                } else if (line.equalsIgnoreCase("ingredients")) {
                    state = ParseState.Ingredients;
                } else if (line.equalsIgnoreCase("instructions")) {
                    state = ParseState.Instructions;
                } else if (line.startsWith("Dietary Restriction")){
                    current_recipe.dietRestriction = line.split(": ")[1];
                    state = ParseState.Diet;
                } else if (line.equalsIgnoreCase("extra")) {
                    state = ParseState.Extra;
                } else if (line.equalsIgnoreCase("nutrition")) {
                    state = ParseState.Nutrition;
                } else {    // if not a key word, add information to the appropriate variable
                    switch (state) {
                        case Ingredients:
                            current_recipe.ingredients += line + "\n";
                            break;
                        case Instructions:
                            current_recipe.instructions += line + "\n";
                            break;
                        case Nutrition:
                            current_recipe.nutritional_info += line + "\n";
                            break;
                    }

                }
            }
            // specifically to add the last recipe
            if (current_recipe != null){
                recipes.add(current_recipe);
            }
        } catch (IOException e) {
            System.out.println("Cannot load recipes from " + FILE_NAME + " due to exception ");
            recipes.clear();
        } finally {
            if (input != null) {
                input.close();
            }
        }
        System.out.println(this.recipes.size() + " recipe records loaded from " + FILE_NAME);
    }


    /**
     * Function: toString
     * Description: Lists all the recipes
     * @return recipe_Title
     */
    @Override
    public String toString(){
        String recipe_Title = "";
        for(int i = 0; i < recipes.size(); i++){
            recipe_Title += recipes.get(i) + "\n";
        }
        return recipe_Title;
    }
}
