import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * The Hospital class is the main class of the Hospital program.
 * It manages all the patients in the Hospital.
 * This includes checking the patient in and out, displaying patient and recipes to the console,
 * matching patients with recipes, and saving and exiting the program.
 *
 * @author Rebecca Xie
 * @version 1.0
 * @since 2018-04
 */

public class Hospital {
    private String FILE_NAME = "patient.txt";
    private ArrayList<Patient> patients;
    static Recipes recipes = new Recipes();

    public static void main(String[] args) {
        recipes.read();
        Hospital hospital = new Hospital();
        hospital.load();
        hospital.manage();
        hospital.save();
    }

    /**
     * Function: manage
     * Description: Allows the client to choose their desired input and perform the required actions,
     * including checking patients in or out, displaying patients and their information, viewing the recipes
     * for the day, matching the patient with a recipe, and exiting and saving the inputted information.
     * @return void
     */
    public void manage(){
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the Hospital");

        while (true){
            System.out.println();
            System.out.println("Please input your option: ");

            System.out.println("(1)checkInPatient = enter patient in hospital\n(2)checkOutPatient = remove patient from hospital" +
                    "\n(3)displayPatients = show name of patients and number of patients\n(4)getRecipe = view all the recipes\n" +
                    "(5)getMatches = match your patients with recipes\n" +
                    "(6)save/exit = save and quit program");
            // Reading commands, taking appropriate action
            int userCommand = input.nextInt();

            if (userCommand == 1){
                Patient patient = readPatientInfo(input);
                checkInPatient(patient);
            } else if (userCommand == 2){
                System.out.println("Please input patient's first name: ");
                input.nextLine();
                String info_firstName = input.nextLine();
                System.out.println("Please input patient's last name: ");
                String info_lastName = input.nextLine();
                System.out.println("Patient name: " + info_firstName + " " + info_lastName);

                Patient patient = findPatient(info_firstName, info_lastName);
                checkOutPatient(patient);
            } else if (userCommand == 3) {
                System.out.println();
                this.display();
            } else if (userCommand == 4) {
                System.out.println();
                System.out.println("OPTIONS FOR TODAY:  ");
                System.out.println(recipes);
            } else if (userCommand == 5) {
                System.out.println();
                //Exception handling
                System.out.println("You have " + this.patients.size() + " patients");
                this.display();

                for(int i = 0; i < patients.size(); i ++){
                    ArrayList<Recipe> matchedRecipes = Matching.Match(patients.get(i), recipes);
                    System.out.println("Recipes for : " + patients.get(i).getPatientFirstName() + " " + patients.get(i).getPatientLastName());
                    for(int j = 0; j < matchedRecipes.size(); j ++){
                        System.out.println("Recipe" + " "+ (j+1) + " : " + matchedRecipes.get(j).title);
                    }
                }
            } else if (userCommand == 6){
                return;
            }
        }
    }

    /**
     * Function: readPatientInfo
     * Description: Allows the client to check in the patient, based on the required fields
     * the method asks. i.e. the patient's name, anthropometrics, food allergies, food likes + dislikes.
     * @param input
     * @return Patient
     */
    private Patient readPatientInfo(Scanner input) {

        System.out.println("Please input patient's first name: ");
        input.nextLine();
        String info_firstName = input.nextLine();
        System.out.println("Please input patient's last name: ");
        String info_lastName = input.nextLine();
        System.out.println("Patient name: " + info_firstName + " " + info_lastName);

        System.out.println("Please input patient's condition. (cancer or diabetes)");
        String condition = input.nextLine();
        //check if patient has entered cancer/diabetes correctly
        System.out.println("Patient condition: " + condition);
        while((!condition.equalsIgnoreCase("cancer")) && (!condition.equalsIgnoreCase("diabetes"))){
            System.out.println("Invalid input. Please re-type input.");
            System.out.println("Please input patient's condition. (cancer or diabetes)");
            condition = input.nextLine();
        }

        System.out.println("Please input patient's weight in kg: ");
        String info_weight = input.nextLine();
        while (!isInt(info_weight)){
            System.out.println("Invalid input. Please re-type input.");
            System.out.println("Please input patient's weight in kg: ");
            info_weight = input.nextLine();
        }
        System.out.println("Patient weight: " + info_weight + " kg");

        System.out.println("Please input patient's usual weight in kg: ");
        String info_usualWeight = input.nextLine();
        while (!isInt(info_usualWeight)){
            System.out.println("Invalid input. Please re-type input.");
            System.out.println("Please input patient's usual weight in kg: ");
            info_usualWeight = input.nextLine();
        }
        System.out.println("Patient's usual weight: " + info_usualWeight + " kg");

        System.out.println("Please input patient's height in meters: ");
        String info_height = input.nextLine();
        while (!isFloat(info_height)) {
            System.out.println("Invalid input. Please re-type input.");
            System.out.println("Patient's height: " + info_height + " m");
            info_height = input.nextLine();
        }
        System.out.println("Please enter patient's food restriction: (none, vegetarian, gluten-free)");
        String info_foodRestriction = input.nextLine();
        while(!info_foodRestriction.equalsIgnoreCase("none") && !info_foodRestriction.equalsIgnoreCase("Vegetarian") && !info_foodRestriction.equalsIgnoreCase("Gluten-free")){
            System.out.println("Invalid input. Please re-type input.");
            System.out.println("Please enter patient's food restriction. (none, vegetarian, gluten-free)");
            info_foodRestriction = input.nextLine();
        }
        System.out.println("Patient's food restriction: " + info_foodRestriction);

        System.out.println("Please enter patient's food allergy: ");
        String info_foodAllergies = input.nextLine();
        System.out.println("Patient's food allergy: " + info_foodAllergies);

        System.out.println("Please input patient's food preference: ");
        String info_foodPreferences = input.nextLine();
        System.out.println("Patient's food preference: " + info_foodPreferences);

        System.out.println("Please input patient's food dislikes: ");
        String info_foodDislikes = input.nextLine();
        System.out.println("Patient's food dislikes: " + info_foodDislikes);

        return new Patient(info_firstName, info_lastName, condition,  Integer.parseInt(info_weight), Integer.parseInt(info_usualWeight), Float.parseFloat(info_height), info_foodRestriction, info_foodAllergies,  info_foodPreferences, info_foodDislikes);
    }

    /**
     * Function: save
     * Description: Displays the number of patients in the patient.txt file
     * @return void
     */
    public void save(){
        try {
            FileWriter fw = new FileWriter(FILE_NAME,false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter outFile = new PrintWriter(bw);
            outFile.println(patients.size());
            for (int i = 0; i < patients.size(); i++) {
                outFile.println(patients.get(i).toString());
            }

            outFile.flush();
            outFile.close();

            System.out.println(patients.size() + " patients saved to " + FILE_NAME);

        } catch(Exception e) {
            System.err.println("Something bad happened...");
        }
    }

    /**
     * Function: load
     * Description: Splits patient information using the delimiter (/). Displays an error message if the
     * file produces an error.
     * @return void
     */
    public void load(){
        Scanner input = null;
        patients = new ArrayList<Patient>();
        try {
            input = new Scanner(new File(FILE_NAME));
            if (input.hasNextLine()) {
                int numOfPatients = input.nextInt();
                input.nextLine();
                for (int i = 0; i < numOfPatients; i++) {
                    String user_input = input.nextLine();
                    String[] attributes = user_input.split("/");
                    if (attributes.length != 10){
                        throw new IOException("Bad file format"); // cannot read file and quit
                    }
                    Patient patient = new Patient(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]), Integer.parseInt(attributes[4]), Float.parseFloat(attributes[5]), attributes[6], attributes[7], attributes[8], attributes[9]);
                    patients.add(patient);
                }
            }
        } catch (IOException e) {
            System.out.println("Exception: " + e.getMessage());
            System.out.println("Cannot load patients from " + FILE_NAME + " due to exception ");
            patients.clear();
        } finally {
            if (input != null) {
                input.close();
            }
        }

        System.out.println(this.patients.size() + " patient records loaded from " + FILE_NAME);
    }

    /**
     * Function: display
     * Description: Displays number of patients and patient information from the patient.txt
     * file onto the console.
     * @return void
     */
    public void display(){
        System.out.println("Total number of records: " + this.patients.size());
        System.out.println("first name/last name/weight(kg)/usual weight(kg)/height(m)/diet restriction/allergies/food preferences/food dislikes" + "\n");

        boolean swapped = true;
        while (swapped){
            swapped = false;

            for (int i = 0; i < this.patients.size() - 1; i++){
                int difference = patients.get(i).getPatientLastName().compareTo(patients.get(i+1).getPatientLastName());
                if (difference > 0){
                    String tempLastName, tempFirstName;
                    tempFirstName = patients.get(i).getPatientFirstName();
                    tempLastName = patients.get(i).getPatientLastName();

                    patients.get(i).setPatientFirstName(patients.get(i+1).getPatientFirstName());
                    patients.get(i+1).setPatientFirstName(tempFirstName);

                    patients.get(i).setPatientLastName(patients.get(i+1).getPatientLastName());
                    patients.get(i+1).setPatientLastName(tempLastName);

                    swapped = true;
                }
            }
        }
        for (int i = 0; i < this.patients.size(); i++)
        {
            System.out.println(patients.get(i) + " ");
        }
    }

    /**
     * Function: findPatient
     * Description: Gets the patient's first and last name.
     * @param firstName
     * @param lastName
     * @return null
     */
    private Patient findPatient(String firstName, String lastName){
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPatientFirstName().equalsIgnoreCase(firstName) && patients.get(i).getPatientLastName().equalsIgnoreCase(lastName)) {
                return patients.get(i);
            }
        }
        return null;
    }

    /**
     * Function: checkInPatient
     * Description: Adds the patient to the array of patients and shows the patient information on the screen.
     * If the patient already exists, it will not add the patient to the array.
     * @param patient
     * @return void
     */
    public void checkInPatient(Patient patient){
        // to see that they are in the hospital already
        Patient existingPatient = findPatient(patient.getPatientFirstName(), patient.getPatientLastName());
        if (existingPatient != null) {
            System.out.println("Patient: " + patient + " checked in: " + existingPatient);
        } else {
            patients.add(patient);
            System.out.println("New patient checked in: " + patient);
        }
    }

    /**
     * Function: checkOutPatient
     * Description: Removes the patient from the array of patients if the patient exists.
     * @param patient
     * @return void
     */
    public void checkOutPatient(Patient patient){
        if (patient != null) {
            patients.remove(patient);
            System.out.println("This patient was removed successfully");
        } else {
            System.out.println("This patient does not exist");
        }
    }

    /**
     * Function: isInt
     * Description: Checks if the input is an integer (valid input)
     * Sources: https://stackoverflow.com/questions/1102891/how-to-check-if-a-string-is-numeric-in-java
     * @param str
     * @return boolean
     */
    public static boolean isInt(String str)
    {
        try
        {
            int i = Integer.parseInt(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;   // if its not an integer
        }
        return true;    // if it is an integer
    }

    /**
     * Function: isFloat
     * Description: Checks if the input is a float (valid input)
     * Sources: https://stackoverflow.com/questions/1102891/how-to-check-if-a-string-is-numeric-in-java
     * @param str
     * @return
     */
    public static boolean isFloat(String str)
    {
        try
        {
            float i = Float.parseFloat(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;   // if its not an integer
        }
        return true;    // if it is an integer
    }
}

