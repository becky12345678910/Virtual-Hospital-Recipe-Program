import java.lang.reflect.Array;
import java.util.ArrayList;
/**
 * The Matching class matches the patient to a recipe that best suits their needs according to the patient
 * information. i.e. condition, food allergies, food likes and dislikes
 * @author Rebecca Xie
 * @version 1.0
 * @since 2018-04
 */
public class Matching {

    /**
     * Function: Match
     * Description: Narrows down the recipes according to the patient's condition, dietary restriction and allergies
     * @param patient
     * @param recipes
     * @return
     */
    public static ArrayList<Recipe> Match(Patient patient, Recipes recipes){

        ArrayList<Recipe> conditionRec = new ArrayList<Recipe>();

        /*
        Finds all the recipes according to the condition of the patient and saves it in a conditionRec array
         */
        for (int i = 0; i < recipes.recipes.size(); i++){
            if(recipes.recipes.get(i).condition.equalsIgnoreCase(patient.getCondition())){
                conditionRec.add(recipes.recipes.get(i));
            }
        }

        ArrayList<Recipe> dietRec = new ArrayList<Recipe>();

        /*
        Finds all the recipes in the conditionRec that have the same dietary restrictions for the patient,
        and saves them in an dietRec array
         */
        for (int i = 0; i < conditionRec.size(); i++){
            if(conditionRec.get(i).dietRestriction.equalsIgnoreCase(patient.getDietRestriction())){
                dietRec.add(conditionRec.get(i));
            }
        }

        /*
        Finds all the recipes in the dietRec array that have the contain the allergies of the patient and saves
        them in an allergy
         */
        ArrayList<Recipe> allergyRec = new ArrayList<Recipe>();

        for (int i = 0; i < dietRec.size(); i++){
            if(!dietRec.get(i).allergy.equalsIgnoreCase(patient.getAllergy())){
                allergyRec.add(dietRec.get(i));
            }
        }


        ArrayList<Recipe> dislikeFoodRec = new ArrayList<Recipe>();

        /*
        Checks to see if there is any food that contains the dislikes of patient and makes a new dislike array of recipes without them
         */
        for (int i = 0; i < allergyRec.size(); i++){
            if(!allergyRec.get(i).ingredients.contains(patient.getDislikedFood())){
                dislikeFoodRec.add(allergyRec.get(i));
            }
        }

        /*
        Checks to see if the dislike array is empty. If it is, no recipes match food preferences.
         */
        if(dislikeFoodRec.isEmpty()){
            System.out.println("No recipes matches food preference. Here are Recipe(s) " +
                    "that match patient's condition and dietary restriction: ");
            return allergyRec;
        }

        ArrayList<Recipe> likeFoodRec = new ArrayList<Recipe>();

        /*
        Checks to see if there is any food that contains the likes of patient and makes a new like array of recipes with them
         */
        for (int i = 0; i < dislikeFoodRec.size(); i++){
            if(dislikeFoodRec.get(i).ingredients.contains(patient.getlikedFood())){
                likeFoodRec.add(dislikeFoodRec.get(i));
            }
        }

        /*
        Checks to see if the dislike array is empty. If it is, no recipes match food preferences.
         */
        if(likeFoodRec.isEmpty()){
            System.out.println("No recipes match food preferences. Here are Recipe(s) that match patient's " +
                    "condition, dietary restriction, food dislike: ");
            return dislikeFoodRec;
        }
        return likeFoodRec;    // if there is no match for the patient
    }
}
