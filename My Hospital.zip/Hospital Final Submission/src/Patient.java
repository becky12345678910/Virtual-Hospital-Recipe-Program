/**
 * The Patient class represents the patient in the Hospital. It includes all the
 * characteristics that the client must fill in before checking the patient into the
 * hospital.
 *
 * @author Rebecca Xie
 * @version 1.0
 * @since 2018-04
 */
public class Patient {
    private String patientLastName, patientFirstName, condition, dietRestriction, patientFoodAllergies, patientFoodPreferences, patientFoodDislikes;
    private int weight, usualWeight;
    private float height;

    /**
     * @param patientFirstName
     * @param patientLastName
     * @param condition
     * @param weight
     * @param usualWeight
     * @param height
     * @param patientFoodAllergies
     * @param patientFoodPreferences
     * @param patientFoodDislikes
     */
    public Patient(String patientFirstName, String patientLastName, String condition, int weight, int usualWeight, float height, String dietRestriction, String patientFoodAllergies
            , String patientFoodPreferences, String patientFoodDislikes){
        this.patientLastName = patientLastName;
        this.patientFirstName = patientFirstName;
        this.condition = condition;
        this.dietRestriction = dietRestriction;
        this.weight = weight;
        this.usualWeight = usualWeight;
        this.height = height;
        this.patientFoodAllergies = patientFoodAllergies;
        this.patientFoodPreferences = patientFoodPreferences;
        this.patientFoodDislikes = patientFoodDislikes;
    }


    /**
     * Function: toString
     * Description: Returns a string representation of the attributes
     * @return str
     */
    public String toString(){
        String str = this.patientFirstName + "/" + this.patientLastName + "/" + this.condition + "/" + Integer.toString(this.usualWeight)+ "/" +
                Integer.toString(this.weight) + "/" + Float.toString(this.height) + "/" + this.dietRestriction + "/" + this.patientFoodAllergies + "/" + this.patientFoodPreferences + "/" + this.patientFoodDislikes;
        return str;
    }

    public String getPatientFirstName(){
        return patientFirstName;
    }

    public String getPatientLastName(){
        return patientLastName;
    }

    public void setPatientLastName(String patientLastName){
        this.patientLastName = patientLastName;
    }

    public void setPatientFirstName(String patientFirstName){
        this.patientFirstName = patientFirstName;
    }

    public String getCondition(){ return condition; }

    public String getAllergy(){return this.patientFoodAllergies;}

    public String getDislikedFood() {return this.patientFoodDislikes;}

    public String getlikedFood() {return this.patientFoodPreferences;}

    public String getDietRestriction(){return this.dietRestriction;}




}
